package com.ecart.dao;

import com.ecart.model.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product(1, "Organic Honey", "Pure organic honey - 500g", 299, "Product1.jpg"));
        products.add(new Product(2, "Green Tea Pack", "Premium green tea 100g", 149, "Product2.jpg"));
        products.add(new Product(3, "Herbal Soap", "Handmade brown herbal soap", 79, "Product3.jpg"));
    }

    public static List<Product> getAllProducts() { return products; }

    public static Product getProductById(int id) {
        for (Product p : products) {
            if (p.getId() == id) return p;
        }
        return null;
    }
}
